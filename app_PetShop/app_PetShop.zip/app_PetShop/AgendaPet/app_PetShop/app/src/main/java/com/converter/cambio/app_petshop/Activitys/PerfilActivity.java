package com.converter.cambio.app_petshop.Activitys;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.converter.cambio.app_petshop.R;

public class PerfilActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
    }
}
