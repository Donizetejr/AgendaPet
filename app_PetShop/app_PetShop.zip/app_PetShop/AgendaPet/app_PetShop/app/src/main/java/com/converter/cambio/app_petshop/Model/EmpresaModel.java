package com.converter.cambio.app_petshop.Model;

public class EmpresaModel {
    private int emp_id;
    private String emp_nome;
    private long emp_telefone;
    private long emp_cnpj;
    private int emp_endereco;
}
